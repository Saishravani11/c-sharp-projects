using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WiproSample.Pages
{
    public class WiproModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
